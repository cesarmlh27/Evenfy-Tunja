import { Routes, Route } from 'react-router-dom'
import { AppProvider } from './context/AppContext'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Toast from './components/Toast'
import Home from './pages/Home'
import Events from './pages/Events'
import EventDetail from './pages/EventDetail'
import { Login, Register } from './pages/Auth'

export default function App() {
  return (
    <AppProvider>
      <Navbar />
      <main style={{ flex: 1 }}>
        <Routes>
          <Route path="/"           element={<Home />} />
          <Route path="/events"     element={<Events />} />
          <Route path="/events/:id" element={<EventDetail />} />
          <Route path="/login"      element={<Login />} />
          <Route path="/register"   element={<Register />} />
          <Route path="*"           element={
            <div style={{ textAlign: 'center', padding: '160px 24px' }}>
              <h1 style={{ fontFamily: 'var(--font-display)', fontSize: '4rem', color: 'var(--terracotta)', marginBottom: 16 }}>404</h1>
              <p style={{ color: '#9a8070', marginBottom: 24 }}>Página no encontrada</p>
              <a href="/" style={{ color: 'var(--terracotta)', fontWeight: 600 }}>← Volver al inicio</a>
            </div>
          }/>
        </Routes>
      </main>
      <Footer />
      <Toast />
    </AppProvider>
  )
}
