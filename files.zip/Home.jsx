import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { ArrowRight, Search, MapPin, Calendar, Star } from 'lucide-react'
import { eventService, categoryService } from '../services/api'
import EventCard from '../components/EventCard'
import './Home.css'

// Datos de ejemplo para cuando la API no esté disponible
const MOCK_EVENTS = [
  { id: 1, title: 'Festival de Luces de Tunja', description: 'Una noche mágica con iluminación artística en el centro histórico.', startDate: '2025-06-15', category: { name: 'Cultura' }, location: { name: 'Plaza de Bolívar' }, attendanceCount: 340 },
  { id: 2, title: 'Concierto en el Parque', description: 'Música en vivo con artistas locales y regionales de Colombia.', startDate: '2025-06-22', category: { name: 'Musica' }, location: { name: 'Parque Pinzón' }, attendanceCount: 180 },
  { id: 3, title: 'Feria Gastronómica Boyacense', description: 'Sabores tradicionales de Boyacá: ajiaco, changua, cocido, y más.', startDate: '2025-07-04', category: { name: 'Gastronomia' }, location: { name: 'Centro Histórico' }, attendanceCount: 520 },
  { id: 4, title: 'Exposición Arte Muisca', description: 'Muestra de arte contemporáneo inspirado en la cultura muisca.', startDate: '2025-07-10', category: { name: 'Arte' }, location: { name: 'Casa de la Cultura' }, attendanceCount: 95 },
  { id: 5, title: 'Maratón Ciudad de Tunja', description: 'Recorre las calles históricas de Tunja en este evento deportivo.', startDate: '2025-07-20', category: { name: 'Deportes' }, location: { name: 'Av. Colón' }, attendanceCount: 620 },
  { id: 6, title: 'Noche de Astronomía', description: 'Observación del cielo andino con telescopios y expertos locales.', startDate: '2025-08-01', category: { name: 'Cultura' }, location: { name: 'Coliseo El Campín' }, attendanceCount: 210 },
]

const MOCK_CATEGORIES = [
  { id: 1, name: 'Cultura', color: '#b05a3c', icon: '🏛️' },
  { id: 2, name: 'Musica',  color: '#4a7fa5', icon: '🎵' },
  { id: 3, name: 'Gastronomia', color: '#3a6b4a', icon: '🍲' },
  { id: 4, name: 'Arte',    color: '#c4843a', icon: '🎨' },
  { id: 5, name: 'Deportes',color: '#7a5ca0', icon: '⚽' },
]

const STATS = [
  { label: 'Eventos activos', value: '40+' },
  { label: 'Categorías', value: '8' },
  { label: 'Usuarios', value: '1.2K' },
  { label: 'Asistencias', value: '5K+' },
]

export default function Home() {
  const [events, setEvents] = useState([])
  const [categories, setCategories] = useState([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [favorites, setFavorites] = useState(new Set())

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [evRes, catRes] = await Promise.all([
          eventService.getAll(),
          categoryService.getAll(),
        ])
        setEvents(evRes.data?.slice(0, 6) || MOCK_EVENTS)
        setCategories(catRes.data || MOCK_CATEGORIES)
      } catch {
        // Usa datos de ejemplo si la API no responde
        setEvents(MOCK_EVENTS)
        setCategories(MOCK_CATEGORIES)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [])

  const toggleFavorite = (id) => {
    setFavorites(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  const filteredEvents = events.filter(e =>
    e.title?.toLowerCase().includes(search.toLowerCase()) ||
    e.description?.toLowerCase().includes(search.toLowerCase())
  )

  return (
    <div className="home">
      {/* Hero */}
      <section className="hero">
        <div className="hero__bg">
          <div className="hero__overlay"/>
          <img
            src="https://images.unsplash.com/photo-1533090161767-e6ffed986c88?w=1600&q=80"
            alt="Tunja ciudad histórica"
            className="hero__img"
          />
        </div>

        <div className="hero__content container">
          <div className="hero__badge animate-fadeUp">
            <MapPin size={14}/> Tunja, Boyacá
          </div>

          <h1 className="hero__title animate-fadeUp animate-fadeUp-delay-1">
            Vive la ciudad<br/>
            <em>a tu manera</em>
          </h1>

          <p className="hero__subtitle animate-fadeUp animate-fadeUp-delay-2">
            Descubre eventos culturales, musicales, gastronómicos<br className="desktop-only"/>
            y más en la histórica ciudad de Tunja.
          </p>

          <div className="hero__search animate-fadeUp animate-fadeUp-delay-3">
            <Search size={18} className="hero__search-icon"/>
            <input
              type="text"
              placeholder="Buscar eventos, lugares, categorías..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
            <Link to={`/events?q=${search}`} className="hero__search-btn">
              Buscar
            </Link>
          </div>

          <div className="hero__stats animate-fadeUp animate-fadeUp-delay-3">
            {STATS.map(s => (
              <div key={s.label} className="hero__stat">
                <strong>{s.value}</strong>
                <span>{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="hero__scroll">
          <span/>
        </div>
      </section>

      {/* Categorías */}
      <section className="section categories-section">
        <div className="container">
          <div className="section__header">
            <h2>Explora por categoría</h2>
            <Link to="/categories" className="section__link">Ver todas <ArrowRight size={16}/></Link>
          </div>
          <div className="categories-grid">
            {(categories.length ? categories : MOCK_CATEGORIES).map((cat, i) => (
              <Link
                to={`/events?category=${cat.id}`}
                key={cat.id}
                className="category-chip animate-fadeUp"
                style={{ animationDelay: `${i * 0.06}s` }}
              >
                <span className="category-chip__icon">{cat.icon || '✦'}</span>
                <span>{cat.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Eventos destacados */}
      <section className="section events-section">
        <div className="container">
          <div className="section__header">
            <h2>
              {search ? `Resultados para "${search}"` : 'Próximos eventos'}
            </h2>
            <Link to="/events" className="section__link">Ver todos <ArrowRight size={16}/></Link>
          </div>

          {loading ? (
            <div className="events-grid">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="event-skeleton">
                  <div className="skeleton" style={{ height: 180 }}/>
                  <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 10 }}>
                    <div className="skeleton" style={{ height: 14, width: '40%' }}/>
                    <div className="skeleton" style={{ height: 20, width: '80%' }}/>
                    <div className="skeleton" style={{ height: 14, width: '60%' }}/>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredEvents.length > 0 ? (
            <div className="events-grid">
              {filteredEvents.map((event, i) => (
                <div key={event.id} className="animate-fadeUp" style={{ animationDelay: `${i * 0.07}s` }}>
                  <EventCard
                    event={event}
                    onFavorite={toggleFavorite}
                    isFavorite={favorites.has(event.id)}
                  />
                </div>
              ))}
            </div>
          ) : (
            <div className="empty-state">
              <span>🔍</span>
              <h3>No encontramos eventos</h3>
              <p>Intenta con otro término de búsqueda</p>
              <button onClick={() => setSearch('')}>Limpiar búsqueda</button>
            </div>
          )}
        </div>
      </section>

      {/* CTA Banner */}
      <section className="cta-banner">
        <div className="container">
          <div className="cta-banner__content">
            <div>
              <h2>¿Tienes un evento en Tunja?</h2>
              <p>Comparte tus eventos con toda la comunidad y llega a más personas.</p>
            </div>
            <Link to="/register" className="cta-banner__btn">
              Publicar evento <ArrowRight size={18}/>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
