import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' },
})

// Interceptor: adjunta el token JWT si existe
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Interceptor: manejo de errores global
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

// ── EVENTOS ──────────────────────────────────────────────
export const eventService = {
  getAll:    ()           => api.get('/events'),
  getById:   (id)         => api.get(`/events/${id}`),
  create:    (data)       => api.post('/events', data),
  update:    (id, data)   => api.put(`/events/${id}`, data),
  delete:    (id)         => api.delete(`/events/${id}`),
  getByCategory: (catId)  => api.get(`/events?categoryId=${catId}`),
}

// ── CATEGORÍAS ───────────────────────────────────────────
export const categoryService = {
  getAll:  () => api.get('/categories'),
  getById: (id) => api.get(`/categories/${id}`),
  create:  (data) => api.post('/categories', data),
}

// ── UBICACIONES ──────────────────────────────────────────
export const locationService = {
  getAll:  () => api.get('/locations'),
  getById: (id) => api.get(`/locations/${id}`),
  create:  (data) => api.post('/locations', data),
}

// ── USUARIOS ─────────────────────────────────────────────
export const userService = {
  getAll:  () => api.get('/users'),
  getById: (id) => api.get(`/users/${id}`),
  create:  (data) => api.post('/users', data),
  update:  (id, data) => api.put(`/users/${id}`, data),
}

// ── COMENTARIOS ──────────────────────────────────────────
export const commentService = {
  getByEvent: (eventId)    => api.get(`/comments?eventId=${eventId}`),
  create:     (data)       => api.post('/comments', data),
  delete:     (id)         => api.delete(`/comments/${id}`),
}

// ── FAVORITOS ────────────────────────────────────────────
export const favoriteService = {
  getByUser:  (userId)     => api.get(`/favorites?userId=${userId}`),
  create:     (data)       => api.post('/favorites', data),
  delete:     (id)         => api.delete(`/favorites/${id}`),
}

// ── ASISTENCIA ───────────────────────────────────────────
export const attendanceService = {
  getByEvent: (eventId)    => api.get(`/event-attendance?eventId=${eventId}`),
  create:     (data)       => api.post('/event-attendance', data),
  delete:     (id)         => api.delete(`/event-attendance/${id}`),
}

export default api
